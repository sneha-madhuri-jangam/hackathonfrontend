import React from 'react';

function About() {
    return (
        <div>
            <h1>thsi is about component</h1>
            
        </div>
    );
}

export default About;