import React from 'react';
// import './index.css'; 
const Home = () => {
  return (
    <div className="container mx-auto mt-4">
      <h1 className="text-2xl font-bold">Home Page</h1>
      <p>This is the Home page content.</p>
    </div>
  );
};

export default Home;